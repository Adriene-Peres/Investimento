import java.util.Random;
public class Moderado implements TipoInvestidor{
    public double chancePorcenteagem(){
        double s = new Random().nextDouble();
        if (s<0.8){
            return 0.006;
        }else{
            return 0.02;
        }
    } 

    public public double calcularValorInvestimento(double investimento, int tempo){
        double valor; 
        for (int i=0;i<tempo;i++){
            valor = investimento + investimento*(chancePorcenteagem());
        }
    }
}
