public interface TipoInvestidor{
    public double calcularValorInvestimento(double investimento, int tempo);
}