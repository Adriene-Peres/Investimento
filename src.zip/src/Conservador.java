public class Conservador implements TipoInvestidor{
    @Override
    public double calcularValorInvestimento(double investimento, int tempo){
        return investimento*(1+0.008)*tempo;
    }
}
