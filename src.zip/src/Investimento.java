public class Investimento{
    private TipoInvestidor inv;

    public Investimento(TipoInvestidor inv){
        this.inv = inv;
    }

    



}